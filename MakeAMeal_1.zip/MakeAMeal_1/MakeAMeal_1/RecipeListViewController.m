//
//  RecipeListViewController.m
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/12/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "RecipeListViewController.h"

@interface RecipeListViewController ()
@property(strong)NSArray *recipeLink;
@end

@implementation RecipeListViewController

@synthesize recipes;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.recipes = @[@"Easy Oven-Baked Chicken Fajitas", @"Baked Chicken and Rice with Autumn Vegetables", @"Jamie's Creamy Baked Chicken Stroganoff", @"Three-Cheese Beef Pasta Shells", @"Beef-Pesto Panini", @"Beef and Veggie Soup with Mozzarella", @"Slow-Cooked Corned Beef Dinner", @"Zesty Deviled Eggs", @"Bacon and Egg Savory Cupcakes", @"Double Bacon Bagel Egg Casserole"];
    
    self.recipeLink = @[@"http://www.bettycrocker.com/recipes/easy-oven-baked-chicken-fajitas/dabcc253-f43e-4b17-b92d-6b6d466ba507", @"http://www.bettycrocker.com/recipes/baked-chicken-and-rice-with-autumn-vegetables/57a80057-3cbe-47ad-8952-83408dbbd44f", @"http://www.bettycrocker.com/recipes/jamies-creamy-baked-chicken-stroganoff/52d09d12-d199-4541-8522-df36f1acacb0", @"http://www.pillsbury.com/recipes/three-cheese-beef-pasta-shells/d812def2-b8ef-472b-b522-76611b47748d", @"http://www.food.com/recipe/beef-pesto-panini-127858", @"http://www.everydayhealth.com/recipes/healthified-beef-n-veggie-soup-with-mozzarella-/", @"http://www.marthastewart.com/891899/slow-cooker-corned-beef-and-cabbage", @"http://www.bettycrocker.com/recipes/zesty-deviled-eggs/f26e4d87-48fb-492d-a5e8-7f793d4ce591", @"http://www.pillsbury.com/recipes/bacon-and-egg-savory-cupcakes/7b59ff89-d049-477b-ae62-1a8ba612e7d5", @"http://www.mastercook.com/app/Recipe/WebRecipeDetails?recipeId=6319586"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.recipes count];
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *SimpleIdentifier = @"SimpleIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SimpleIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpleIdentifier];
    }
    cell.textLabel.text = self.recipes[indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //- (IBAction)openDaleDietrichDotCom:(id)sender
    //{
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString: [self.recipeLink objectAtIndex: indexPath.row]]];
    
    //}
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
