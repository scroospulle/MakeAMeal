//
//  IngredientsListViewController.m
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/12/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "IngredientsListViewController.h"

@interface IngredientsListViewController ()

@end

@implementation IngredientsListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.ingredients = @[@"Chicken", @"Beef", @"Carrots", @"Corn", @"Bread", @"Rice", @"Pasta", @"Cheese", @"Eggs", @"Milk"];
    
   // _mTableView.delegate = self;
   // _mTableView.datasource = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.ingredients count];
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *SimpleIdentifier = @"SimpleIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SimpleIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpleIdentifier];
    }
    cell.textLabel.text = self.ingredients[indexPath.row];
    //return cell {
        //if (editingStyle)
    //}
    return cell;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath;
{}
//#pragma amrk - UITableView Delegate
//- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    //return UITableViewCellEditingStyleDelete;
//}




@end


