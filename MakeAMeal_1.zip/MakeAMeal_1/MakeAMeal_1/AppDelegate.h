//
//  AppDelegate.h
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/11/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

