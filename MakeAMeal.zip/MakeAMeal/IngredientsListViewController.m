//
//  IngredientsListViewController.m
//  MakeAMeal
//
//  Created by Shiny Croospulle on 4/5/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "IngredientsListViewController.h"
#import "IngredientsCell.h"

#define TABLE_CELL_HEIGHT 90.0f

@interface IngredientsListViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (nonatomic, strong) NSMutableArray *loadedIngredientsData;

@end

@implementation IngredientsListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.loadedIngredientsData = [[NSMutableArray alloc] init];
    [self loadJSONData];
}

- (void)loadJSONData
{
    //loads data in a separate thread
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"ingredientsData" ofType:@"json"];
        
        NSError *error = nil;
        
        NSData *rawData = [NSData dataWithContentsOfFile:filePath options:NSDataReadingMappedIfSafe error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            NSError *error = nil;
            id JSONData = [NSJSONSerialization JSONObjectWithData:rawData options:NSJSONReadingAllowFragments error:&error];
            
            [self.loadedIngredientsData removeAllObjects];
            if ([JSONData isKindOfClass:[NSDictionary class]])
            {
                NSDictionary *jsonDict = (NSDictionary *)JSONData;
                
                NSArray *loadedArray = [jsonDict objectForKey:@"data"];
                if ([loadedArray isKindOfClass:[NSArray class]])
                {
                    for (NSDictionary *ingredientsDict in loadedArray)
                    {
                        IngredientsData *ingredientsData = [[IngredientsData alloc] init];
                        [ingredientsData loadWithDictionary:ingredientsDict];
                        [self.loadedIngredientsData addObject:ingredientsData];
                    }
                }
            }
            
            [self.tableview reloadData];
        });
    });
    
    
    
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*- (IBAction)backAction:(id)sender
{
    MainMenuViewController *mainMenuViewController = [[MainMenuViewController alloc] init];
    [self.navigationController pushViewController:mainMenuViewController animated:YES];
}
*/
#pragma mark - UITableViewDataSource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"IngredientsCell";
    
    IngredientsCell *cell = (IngredientsCell *)[tableView dequeueReusableCellWithIdentifier: cellIdentifier];;
    
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:cellIdentifier owner:self options:nil];
        cell = (IngredientsCell *)[nib objectAtIndex:0];
    }
    
    IngredientsData *ingredientsData = [self.loadedIngredientsData objectAtIndex:[indexPath row]];
    
    [cell loadWithData:ingredientsData];
    
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.loadedIngredientsData.count;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return TABLE_CELL_HEIGHT;
}
@end
