//
//  IngredientsData.h
//  MakeAMeal
//
//  Created by Shiny Croospulle on 4/5/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IngredientsData : NSObject
@property (nonatomic, readwrite) int ingredient_id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, readwrite) int *quantity;
- (void)loadWithDictionary:(NSDictionary *)dict;

@end

