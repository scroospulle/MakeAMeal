//
//  AppDelegate.h
//  MakeAMeal
//
//  Created by Shiny Croospulle on 4/5/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

