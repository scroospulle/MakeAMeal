//
//  IngredientsData.m
//  MakeAMeal
//
//  Created by Shiny Croospulle on 4/5/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "IngredientsData.h"

@implementation IngredientsData
- (void)loadWithDictionary:(NSDictionary *)dict
{
    self.ingredient_id = [[dict objectForKey:@"ingredient_id"] intValue];
    self.name = [dict objectForKey:@"name"];
    //self.quantity = [[dict objectForKey:@"quantity"]intValue];
}
@end
