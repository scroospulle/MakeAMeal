//
//  AddIngredientsViewController.m
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/12/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "AddIngredientsViewController.h"
#import "IngredientsListViewController.h"
@interface AddIngredientsViewController ()

@end

@implementation AddIngredientsViewController

@synthesize aNewIngredient, typeOfIngredient, addNewIngredient;


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.catalog == nil){ // Make sure an instance of `Catalog` has been created!
        self.catalog = [[ingList alloc] init];
    }

    self.aNewIngredient.delegate = self;
    self.typeOfIngredient.delegate = self;
    // Do any additional setup after loading the view.
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"addIng1"]) {
        IngredientsListViewController *pvc = segue.destinationViewController;
        pvc.catalog = self.catalog; // Pass the catalog between the view controllers.
    }
    else if ([segue.identifier isEqualToString:@"goback"]) {
        IngredientsListViewController *pvc = segue.destinationViewController;
        pvc.catalog = self.catalog; // Pass the catalog between the view controllers.
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)addButton:(id)sender {
    [_catalog.products addObject:aNewIngredient.text];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
