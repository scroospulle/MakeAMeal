//
//  ViewController.m
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/11/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (copy, nonatomic) NSArray *ingredList;
@property (copy, nonatomic) NSArray *instructList;
@property (weak, nonatomic) IBOutlet UITableView *ingredtable;
@property (weak, nonatomic) IBOutlet UITableView *instructTable;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.recipe == nil){
        self.recipe = [[NSString alloc] init];
    }
    
    // Do any additional setup after loading the view, typically from a nib.
    if ([_recipe  isEqual: @"Fried Chicken Sandwich"]){
        self.ingredList = @[@"chicken",@"tomato",@"potato sandwich buns",@"lettuce"];
        self.instructList = @[@"Fry Chicken to your choice",@"open sandwich buns",@"place tomato and lettuce into bun", @"add the fried chicken"];
    }
    else if ([_recipe  isEqual: @"fried eggs with tomatoes"]){
        self.ingredList = @[@"egg",@"tomato"];
        self.instructList = @[@"stir eggs",@"add tomato slices",@"combine them together"];
    }
    else if ([_recipe  isEqual: @"fried egg"]){
        self.ingredList = @[@"egg"];
        self.instructList = @[@"Fry egg on pan"];
    }
    
    else if ([_recipe  isEqual: @"Chicken Soup"]){
        self.ingredList = @[@"chicken",@"carrot",@"celery",@"onion", @"rice"];
        self.instructList = @[@"Put water to boil",@"add chicken to water",@"boil rice", @"add sliced veggetable to chicken", @"add the cooked rice into the chicken"];
    }
    else if ([_recipe  isEqual: @"Spaghetti with Sausage and Tomato Sauce"]){
        self.ingredList = @[@"sausage",@"spaghetti",@"tomato",@"garlic"];
        self.instructList = @[@"Fry sausages on the pan",@"boil spaghetti till soft",@"add minced garlic to spaghetti", @"Fry spaghetti with blended tomatoes"];
    }
    _rName.text = _recipe;
    
}

-(NSInteger)tableView: (UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == self.ingredtable){
        return [self.ingredList count];
    }
    else if(tableView == self.instructTable){
        return [self.instructList count];
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    
    if(tableView == self.ingredtable){
        
        NSString *s = [self.ingredList objectAtIndex:indexPath.row];
        cell.textLabel.text = s;
    }
    
    else if(tableView == self.instructTable){
        
        NSString *m = [self.instructList objectAtIndex:indexPath.row];
        cell.textLabel.text = m;
        
    }
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
