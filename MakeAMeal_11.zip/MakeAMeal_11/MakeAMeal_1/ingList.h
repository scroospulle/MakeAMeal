//
//  ingList.h
//  MakeAMeal_1
//
//  Created by Jesus Leal on 5/10/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ingList : NSObject
@property (nonatomic) NSMutableArray *products;

@end
