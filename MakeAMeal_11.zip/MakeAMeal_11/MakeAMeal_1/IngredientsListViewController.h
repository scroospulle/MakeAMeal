//
//  IngredientsListViewController.h
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/12/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ingList.h"

@interface IngredientsListViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
    
    NSMutableArray *dataArray;
}

- (IBAction)didTapEditBtnAction:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *mTableView;
@property (strong, nonatomic) ingList *catalog;

@end

