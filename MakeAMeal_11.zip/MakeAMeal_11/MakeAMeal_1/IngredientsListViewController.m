//
//  IngredientsListViewController.m
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/12/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "IngredientsListViewController.h"
#import "RecipeListViewController.h"
#import "AddIngredientsViewController.h"
#import "MainMenuViewController.h"

@interface IngredientsListViewController ()

@end

@implementation IngredientsListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.catalog == nil){
        self.catalog = [[ingList alloc] init];
    }
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"addIng"]) {
        AddIngredientsViewController *pvc = segue.destinationViewController;
        pvc.catalog = self.catalog; // Pass the catalog between the view controllers.
    }
    else if ([segue.identifier isEqualToString:@"movetoMV"]) {
        MainMenuViewController *pvc = segue.destinationViewController;
        pvc.catalog = self.catalog; // Pass the catalog between the view controllers.
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)didTapEditBtnAction:(id)sender {
    [_mTableView setEditing:YES animated:YES];
}

#pragma mark - UITableView DataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_catalog.products count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID=@"cellID";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell==Nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    cell.textLabel.text = [_catalog.products objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [_catalog.products removeObjectAtIndex:indexPath.row];
        [_mTableView deleteRowsAtIndexPaths:[NSMutableArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma amrk - UITableView Delegate

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleDelete;
}

@end



