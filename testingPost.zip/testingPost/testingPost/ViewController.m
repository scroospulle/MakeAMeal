//
//  ViewController.m
//  testingPost
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 Jesus Leal. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize responseData;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    // Create the request.
    //NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://passus.poly.edu/registration.php"]];
    
    // Specify that it will be a POST request
    
    // This is how we set header field

    NSString *post = [NSString stringWithFormat:@"email=%@ & password=%@ & f_name=%@ & l_name = %@ & student= %@", @"jleal6282@gmail.com", @"password", @"Jesus", @"Leal", @"1"];
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:NO];
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[post length]];
    // Convert your data and set your request's HTTPBody property
    //NSString *stringData = @"";
    //NSData *requestBodyData = [stringData dataUsingEncoding:NSUTF8StringEncoding];
    //request.HTTPBody = requestBodyData;
    NSString *url = [NSString stringWithFormat:@"http://passus.poly.edu/registration.php"];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:postData];
    // Create url connection and fire request
    NSURLSessionDataTask *downloadTask = [[NSURLSession sharedSession]
    dataTaskWithURL:[NSURL URLWithString:url] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        data = [[NSMutableData alloc] init];
        responseData = data;
    }];
    
    // 3
    [downloadTask resume];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
