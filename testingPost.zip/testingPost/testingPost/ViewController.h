//
//  ViewController.h
//  testingPost
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 Jesus Leal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong) NSData *responseData;

@end

