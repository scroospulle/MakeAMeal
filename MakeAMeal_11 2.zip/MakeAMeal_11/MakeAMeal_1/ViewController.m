//
//  ViewController.m
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/11/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (copy, nonatomic) NSArray *ingredList;
@property (copy, nonatomic) NSArray *instructList;
@property (weak, nonatomic) IBOutlet UITableView *ingredtable;
@property (weak, nonatomic) IBOutlet UITableView *instructTable;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.ingredList = @[@"chicken",@"tomato",@"potato sandwich buns",@"lettuce"];
    self.instructList = @[@"Fry Chicken to your choice",@"open sandwich buns",@"place tomato and lettuce into bun", @"add the fried chicken"];
}

-(NSInteger)tableView: (UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == self.ingredtable){
        return [self.ingredList count];
    }
    else if(tableView == self.instructTable){
        return [self.instructList count];
    }
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    
    if(tableView == self.ingredtable){
        
        NSString *s = [self.ingredList objectAtIndex:indexPath.row];
        cell.textLabel.text = s;
    }
    
    else if(tableView == self.instructTable){
        
        NSString *m = [self.instructList objectAtIndex:indexPath.row];
        cell.textLabel.text = m;
        
    }
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
