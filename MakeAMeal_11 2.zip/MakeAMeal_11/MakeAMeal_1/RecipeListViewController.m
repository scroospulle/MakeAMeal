//
//  RecipeListViewController.m
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 4/12/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "RecipeListViewController.h"
#import "ASIFormDataRequest.h"


@interface RecipeListViewController ()
@property(strong)NSArray *recipeLink;
@property NSDictionary *jsonObject;
@property (weak, nonatomic) IBOutlet UITableView *recipeTable;

@end

@implementation RecipeListViewController

@synthesize recipes;


- (void)viewDidLoad {
    [super viewDidLoad];
    NSURL *url=[NSURL URLWithString:@"http://www.friendprint.dx.am/localApples/getRecipe.php"];
    ASIFormDataRequest *request=[ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:@"egg" forKey:@"ingredient"];
    [request startSynchronous];
    NSString *response = [request responseString];
    NSLog(@"responseString is %@",response);
    NSMutableString *mutableString = [response mutableCopy];
    [mutableString replaceOccurrencesOfString:@"["
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    [mutableString replaceOccurrencesOfString:@"{"
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    [mutableString replaceOccurrencesOfString:@"]"
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    [mutableString replaceOccurrencesOfString:@"}"
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    [mutableString replaceOccurrencesOfString:@"\""
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    [mutableString replaceOccurrencesOfString:@"rid"
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    [mutableString replaceOccurrencesOfString:@"rname"
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    [mutableString replaceOccurrencesOfString:@"ingredlist"
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    [mutableString replaceOccurrencesOfString:@"["
                                   withString:@""
                                      options:0
                                        range:NSMakeRange(0, mutableString.length)];
    
    NSLog(@"the new string is %@",mutableString);
    const char * temp = [mutableString UTF8String];
    NSMutableArray *keysAndvalues = [[NSMutableArray alloc] init];
    int rid = 1;
    
    NSMutableString *rname = [NSMutableString string];
    NSMutableString *ingredlist = [NSMutableString string];
    
    for (int i = 0; i < mutableString.length; i++) {
        
        NSNumber *theTemp = [NSNumber numberWithChar:temp[i]];
        NSNumber *theRid = [NSNumber numberWithChar:rid+48];
        if (theTemp == theRid )
        {
            int findRname = i+3;
            NSNumber *theRtemp = [NSNumber numberWithChar:temp[findRname]];
            NSNumber *theComma = [NSNumber numberWithChar:','];
            
            while (theRtemp != theComma)
            {
                //Append a Character
                char ch = temp[findRname];
                [rname appendFormat: @"%c",ch];
                findRname = findRname+1;
                theRtemp = [NSNumber numberWithChar:temp[findRname]];
            }
            NSLog(@"the whole rname is %@",rname);
            NSString* string = rname;
            [keysAndvalues addObject:string];
            rname = [NSMutableString string];
            
            int findIngreds = findRname +2;
            NSNumber *theItemp = [NSNumber numberWithChar:temp[findIngreds]];
            NSNumber *theColon = [NSNumber numberWithChar:':'];
            while ( theItemp != theColon)
            {
                char ch = temp[findIngreds];
                [ingredlist appendFormat:@"%c",ch];
                findIngreds = findIngreds +1;
                theItemp = [NSNumber numberWithChar:temp[findIngreds]];
                if (findIngreds+1 > mutableString.length ){break;}
            }
            NSLog(@"the whole ingredlist is %@",ingredlist);
            NSMutableString* string2 = ingredlist;
            [keysAndvalues addObject:string2];
            ingredlist = [NSMutableString string];
            rid++;
        }
    }
    
    for (int i = 0; i < [keysAndvalues count]; i++) {
        NSLog(@"the i value is %@", keysAndvalues[i]);
    }


    // Do any additional setup after loading the view.
    self.recipes = @[@"fried eggs with tomatoes", @"fried egg", @"Fried Chicken Sandwich", @"Chicken Soup", @"Spaghetti with Sausage and Tomato Sauce"];
    
    self.recipeLink = @[@"",@"http://www.bettycrocker.com/recipes/easy-oven-baked-chicken-fajitas/dabcc253-f43e-4b17-b92d-6b6d466ba507", @"http://www.bettycrocker.com/recipes/baked-chicken-and-rice-with-autumn-vegetables/57a80057-3cbe-47ad-8952-83408dbbd44f", @"http://www.bettycrocker.com/recipes/jamies-creamy-baked-chicken-stroganoff/52d09d12-d199-4541-8522-df36f1acacb0", @"http://www.pillsbury.com/recipes/three-cheese-beef-pasta-shells/d812def2-b8ef-472b-b522-76611b47748d", @"http://www.food.com/recipe/beef-pesto-panini-127858", @"http://www.everydayhealth.com/recipes/healthified-beef-n-veggie-soup-with-mozzarella-/", @"http://www.marthastewart.com/891899/slow-cooker-corned-beef-and-cabbage", @"http://www.bettycrocker.com/recipes/zesty-deviled-eggs/f26e4d87-48fb-492d-a5e8-7f793d4ce591", @"http://www.pillsbury.com/recipes/bacon-and-egg-savory-cupcakes/7b59ff89-d049-477b-ae62-1a8ba612e7d5", @"http://www.mastercook.com/app/Recipe/WebRecipeDetails?recipeId=6319586"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.recipes count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    
    if(tableView == self.recipeTable){
        
        NSString *s = [self.recipes objectAtIndex:indexPath.row];
        cell.textLabel.text = s;
    }
    return cell;
}


/*- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *SimpleIdentifier = @"SimpleIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SimpleIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpleIdentifier];
    }
    cell.textLabel.text = self.recipes[indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //- (IBAction)openDaleDietrichDotCom:(id)sender
    //{
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString: [self.recipeLink objectAtIndex: indexPath.row]]];
    
    //}
}*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
