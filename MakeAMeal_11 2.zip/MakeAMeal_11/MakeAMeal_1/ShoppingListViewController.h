//
//  ShoppingListViewController.h
//  MakeAMeal_1
//
//  Created by Shiny Croospulle on 5/3/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShoppingListViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
    
    NSMutableArray *dataArray;
}

- (IBAction)didTapEditBtnAction:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *mTableView;

@end
